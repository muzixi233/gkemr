package com.slwh.emr.model;

public class Menu_PermissionKey {
    private Integer mId;

    private Integer peId;

    public Integer getmId() {
        return mId;
    }

    public void setmId(Integer mId) {
        this.mId = mId;
    }

    public Integer getPeId() {
        return peId;
    }

    public void setPeId(Integer peId) {
        this.peId = peId;
    }
}