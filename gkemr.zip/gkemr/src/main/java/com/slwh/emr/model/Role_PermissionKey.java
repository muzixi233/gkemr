package com.slwh.emr.model;

public class Role_PermissionKey {
    private Integer rId;

    private Integer peId;

    public Integer getrId() {
        return rId;
    }

    public void setrId(Integer rId) {
        this.rId = rId;
    }

    public Integer getPeId() {
        return peId;
    }

    public void setPeId(Integer peId) {
        this.peId = peId;
    }
}