<!--�汾�ţ�0001-->
<!--Action:2-->
<!--
Location_CodeId = new Array;
Location_ParentId = new Array;
Location_CodeValue = new Array;
Location_IsVisible = new Array;
Location_Lvl = new Array;
I=-1;


/*I++;
Location_CodeId[I] = '16000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '��Ա������Ϣ�Ӽ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';
*/

I++;
Location_CodeId[I] = '40';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '��Ա���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '16010';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '225';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '16050';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '�Ա�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '16020';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '��������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '16030';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '117';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = 'Ѫ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '125';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '����֤����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '16040';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '16060';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '16080';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '�������ڵ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '16070';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '180';
Location_ParentId[I] = '16000';
Location_CodeValue[I] = '����״��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


/*I++;
Location_CodeId[I] = '7000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '��������Ӽ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';
*/

I++;
Location_CodeId[I] = '100';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '��Ա���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '7010';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '�μӿ���ʱ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '18';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '7020';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '������Գɼ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '7070';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '�����ɼ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '7060';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '���Գɼ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '220';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '�ۺϿ��Գɼ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '7040';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '�����ۺ�ӡ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '152';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '¼ȡ���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '7030';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '��������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';

/*
I++;
Location_CodeId[I] = '167';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '7080';
Location_ParentId[I] = '7000';
Location_CodeValue[I] = '��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '8000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '������ѵ�Ӽ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';
*/

I++;
Location_CodeId[I] = '55';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = '��Ա���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '107';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = 'ѧϰ����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '147';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = 'ѧ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '8050';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = 'ѧϰ��ʼʱ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '8060';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = 'ѧϰ����ʱ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '8080';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = '���ڹ���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '8090';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = 'ϵ������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '73';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = '������ѵ�������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '8110';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = '������ѵ����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '8100';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = '������ѵ�ں�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '8070';
Location_ParentId[I] = '8000';
Location_CodeValue[I] = '������ѵ���쵥λ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';

/*
I++;
Location_CodeId[I] = '9000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '��ͥ��Ա�Ӽ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';
*/

I++;
Location_CodeId[I] = '65';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = 'н��С��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '9040';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = 'н�꼶��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '9030';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = 'н�굵��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '9020';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = '���ʱ�׼����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '9021';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = '������ʶ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '9022';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = '���ʺϼ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '9023';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = '��������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '9024';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = 'ְ����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '9025';
Location_ParentId[I] = '9000';
Location_CodeValue[I] = '��λ����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';

/*
I++;
Location_CodeId[I] = '10000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '��ʷ����ż����Ӽ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';
*/

I++;
Location_CodeId[I] = '35';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '��Ա���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '10030';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '��ż���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '155';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '��ż����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '10040';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '�Ա�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '156';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '��Ƭ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '157';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '��������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '158';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '159';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '160';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '161';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '������ò';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '162';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '������λ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '163';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '�μӹ���ʱ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '164';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = 'ְ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '165';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = 'ѧ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '166';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = 'ѧλ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '167';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '��ҵԺУ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '168';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = 'ϵ������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '169';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = 'רҵ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '170';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '171';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '�������ճ̶�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '172';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '���֤��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '173';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '���ʱ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '174';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = '����״��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '175';
Location_ParentId[I] = '10000';
Location_CodeValue[I] = 'רҵ����ְ������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '24000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '85';
Location_ParentId[I] = '24000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '24020';
Location_ParentId[I] = '24000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '24030';
Location_ParentId[I] = '24000';
Location_CodeValue[I] = '��Ȫ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '17000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '105';
Location_ParentId[I] = '17000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '17040';
Location_ParentId[I] = '17000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '42';
Location_ParentId[I] = '17000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '17020';
Location_ParentId[I] = '17000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '17050';
Location_ParentId[I] = '17000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '20000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '45';
Location_ParentId[I] = '20000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '20020';
Location_ParentId[I] = '20000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '18000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '50';
Location_ParentId[I] = '18000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '18020';
Location_ParentId[I] = '18000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '1000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '�ӱ�ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '130';
Location_ParentId[I] = '1000';
Location_CodeValue[I] = 'ʯ��ׯ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '7';
Location_ParentId[I] = '1000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '1070';
Location_ParentId[I] = '1000';
Location_CodeValue[I] = '�е�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '53';
Location_ParentId[I] = '1000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '1080';
Location_ParentId[I] = '1000';
Location_CodeValue[I] = '�ȷ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '1030';
Location_ParentId[I] = '1000';
Location_CodeValue[I] = '�ػʵ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '1020';
Location_ParentId[I] = '1000';
Location_CodeValue[I] = '��ɽ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '1060';
Location_ParentId[I] = '1000';
Location_CodeValue[I] = '�żҿ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '13000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '175';
Location_ParentId[I] = '13000';
Location_CodeValue[I] = '֣��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '78';
Location_ParentId[I] = '13000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '92';
Location_ParentId[I] = '13000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '6000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '������ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '60';
Location_ParentId[I] = '6000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '6030';
Location_ParentId[I] = '6000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '6040';
Location_ParentId[I] = '6000';
Location_CodeValue[I] = '��ľ˹';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '6050';
Location_ParentId[I] = '6000';
Location_CodeValue[I] = 'ĵ����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '6020';
Location_ParentId[I] = '6000';
Location_CodeValue[I] = '�������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '14000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '150';
Location_ParentId[I] = '14000';
Location_CodeValue[I] = '�人';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '14020';
Location_ParentId[I] = '14000';
Location_CodeValue[I] = 'ʮ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '14040';
Location_ParentId[I] = '14000';
Location_CodeValue[I] = '�差';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '14030';
Location_ParentId[I] = '14000';
Location_CodeValue[I] = '�˲�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '14050';
Location_ParentId[I] = '14000';
Location_CodeValue[I] = 'Ǳ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '14060';
Location_ParentId[I] = '14000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '14070';
Location_ParentId[I] = '14000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '14080';
Location_ParentId[I] = '14000';
Location_CodeValue[I] = '��ʯ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '15000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '15';
Location_ParentId[I] = '15000';
Location_CodeValue[I] = '��ɳ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;

Location_CodeId[I] = '15030';
Location_ParentId[I] = '15000';
Location_CodeValue[I] = '��̶';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '15020';
Location_ParentId[I] = '15000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '5000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '10';
Location_ParentId[I] = '5000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '5020';
Location_ParentId[I] = '5000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '11000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '95';
Location_ParentId[I] = '11000';
Location_CodeValue[I] = '�ϲ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '11020';
Location_ParentId[I] = '11000';
Location_CodeValue[I] = '�Ž�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '4000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '120';
Location_ParentId[I] = '4000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '4030';
Location_ParentId[I] = '4000';
Location_CodeValue[I] = '��ɽ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '30';
Location_ParentId[I] = '4000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '4040';
Location_ParentId[I] = '4000';
Location_CodeValue[I] = '��«��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '3000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '���ɹ�������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '70';
Location_ParentId[I] = '3000';
Location_CodeValue[I] = '���ͺ���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '3020';
Location_ParentId[I] = '3000';
Location_CodeValue[I] = '��ͷ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '3030';
Location_ParentId[I] = '3000';
Location_CodeValue[I] = '���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '26000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '170';
Location_ParentId[I] = '26000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '25000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '�ຣʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '165';
Location_ParentId[I] = '25000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = 'ɽ��ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '75';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12090';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12040';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '��Ӫ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12060';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12100';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '110';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '�ൺ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12080';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12070';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '̩��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '146';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12050';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = 'Ϋ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '168';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '��̨';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '12030';
Location_ParentId[I] = '12000';
Location_CodeValue[I] = '�Ͳ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '2000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = 'ɽ��ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '135';
Location_ParentId[I] = '2000';
Location_CodeValue[I] = '̫ԭ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '2010';
Location_ParentId[I] = '2000';
Location_CodeValue[I] = '��ͬ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '2020';
Location_ParentId[I] = '2000';
Location_CodeValue[I] = '�ٷ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '2030';
Location_ParentId[I] = '2000';
Location_CodeValue[I] = '�˳�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '23000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '160';
Location_ParentId[I] = '23000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '23010';
Location_ParentId[I] = '23000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '23020';
Location_ParentId[I] = '23000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '19000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '�Ĵ�ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '20';
Location_ParentId[I] = '19000';
Location_CodeValue[I] = '�ɶ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '19060';
Location_ParentId[I] = '19000';
Location_CodeValue[I] = '��ɽ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '19030';
Location_ParentId[I] = '19000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '19040';
Location_ParentId[I] = '19000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '19050';
Location_ParentId[I] = '19000';
Location_CodeValue[I] = '�ڽ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '19070';
Location_ParentId[I] = '19000';
Location_CodeValue[I] = '�˱�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '19020';
Location_ParentId[I] = '19000';
Location_CodeValue[I] = '�Թ�';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '22000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '90';
Location_ParentId[I] = '22000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '22020';
Location_ParentId[I] = '22000';
Location_CodeValue[I] = '�տ���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '27000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '�½�������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '145';
Location_ParentId[I] = '27000';
Location_CodeValue[I] = '��³ľ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '27030';
Location_ParentId[I] = '27000';
Location_CodeValue[I] = '��ʲ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '27020';
Location_ParentId[I] = '27000';
Location_CodeValue[I] = '��������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '27040';
Location_ParentId[I] = '27000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '21000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����ʡ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '80';
Location_ParentId[I] = '21000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '21030';
Location_ParentId[I] = '21000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '21040';
Location_ParentId[I] = '21000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '21020';
Location_ParentId[I] = '21000';
Location_CodeValue[I] = '��Ϫ';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '34000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '185';
Location_ParentId[I] = '34000';
Location_CodeValue[I] = '���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '35000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '190';
Location_ParentId[I] = '35000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '36000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '̨��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '195';
Location_ParentId[I] = '36000';
Location_CodeValue[I] = '̨��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '37000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '�������޹��Һ͵���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '200';
Location_ParentId[I] = '37000';
Location_CodeValue[I] = '�������޹��Һ͵���';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '38000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '205';
Location_ParentId[I] = '38000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '41000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '230';
Location_ParentId[I] = '41000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '39000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '210';
Location_ParentId[I] = '39000';
Location_CodeValue[I] = '������';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '40000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = 'ŷ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '215';
Location_ParentId[I] = '40000';
Location_CodeValue[I] = 'ŷ��';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';


I++;
Location_CodeId[I] = '42000';
Location_ParentId[I] = '0';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '1';


I++;
Location_CodeId[I] = '235';
Location_ParentId[I] = '42000';
Location_CodeValue[I] = '����';
Location_IsVisible[I] = '1';
Location_Lvl[I] = '2';
//-->